import winreg as reg
import tkinter as tk
from tkinter import messagebox, simpledialog

def retirer_du_demarrage():

    A=simpledialog.askstring("APOGIP","mot de passe")
    if A=="J'aimeMissBl0omie":
        messagebox.showinfo("APOGIP","désintalation réussi")
        # Le même nom que tu as utilisé pour l'ajouter
        nom_application = "APOGIP_Base"
    
        cle_registre = reg.HKEY_CURRENT_USER
        chemin_cle = r"Software\Microsoft\Windows\CurrentVersion\Run"
    
        try:
            # Ouvre la clé de registre en mode édition (KEY_ALL_ACCESS ou KEY_SET_VALUE)
            open_cle = reg.OpenKey(cle_registre, chemin_cle, 0, reg.KEY_SET_VALUE)
            # Supprime la valeur correspondante à ton application
            reg.DeleteValue(open_cle, nom_application)
            reg.CloseKey(open_cle)
            print("APOGIP a été retiré avec succès du démarrage !")
        except FileNotFoundError:
            messagebox.showinfo("system","Apogip n'était malhereusement pas présent dans le démarrage.")
        except Exception as e:
            messagebox.showinfo("APOGIP","Erreur lors de la suppression :", e)

# Exécute la fonction de nettoyage
retirer_du_demarrage()