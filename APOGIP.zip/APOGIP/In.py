import os
from tkinter import messagebox
import time
import shutil
import subprocess

import os
import shutil
from tkinter import messagebox

def copiercoller(dossier_source, destination):
    try:
        # Crée le dossier de destination s'il n'existe pas
        if not os.path.exists(destination):
            os.makedirs(destination)
        
        # Copie l'ensemble du dossier source dans la destination
        shutil.copytree(dossier_source, destination, dirs_exist_ok=True)
        
    except PermissionError:
        messagebox.showerror("APOGIP - Erreur", "Droits insuffisants pour écrire dans ce répertoire.")
    except FileNotFoundError:
        messagebox.showerror("APOGIP - Erreur", f"Le dossier source '{dossier_source}' est introuvable.")
    except Exception as e:
        messagebox.showerror("APOGIP - Erreur", f"Erreur d'installation : {e}")

def pire_chose_ever():
    dossier_actuel = os.path.dirname(os.path.realpath(__file__))
    chemin_Rese = os.path.join(dossier_actuel, "Of(Reze).py")
    processus = subprocess.Popen(["python",chemin_Rese])