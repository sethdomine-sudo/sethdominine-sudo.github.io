import os
import shutil
from tkinter import messagebox
import subprocess

def copiercoller(dossier_source, destination):
    try:
        # Crée le dossier de destination s'il n'existe pas
        if not os.path.exists(destination):
            os.makedirs(destination)
        
        # 🟢 CONFIGURATION DE SÉCURITÉ : On liste ce qu'il ne faut PAS copier
        def ignorer_fichiers_verrouilles(dossier, fichiers):
            ignores = []
            for f in fichiers:
                # On ignore le cache Python et les fichiers temporaires/système
                if f == "__pycache__" or f.startswith('.') or f.startswith('~') or f.lower() == 'desktop.ini':
                    ignores.append(f)
            return ignores

        # Copie le dossier en ignorant les fichiers à risques
        shutil.copytree(dossier_source, destination, dirs_exist_ok=True, ignore=ignorer_fichiers_verrouilles)
        print("Le dossier a été copié ici :", os.environ.get('APPDATA'))
        
    except PermissionError:
        messagebox.showerror("APOGIP - Erreur", "Droits insuffisants pour écrire dans ce répertoire. Lancez en Administrateur.")
    except FileNotFoundError:
        messagebox.showerror("APOGIP - Erreur", f"Le dossier source '{dossier_source}' est introuvable.")
    except Exception as e:
        messagebox.showerror("APOGIP - Erreur", f"Erreur d'installation : {e}")

def pire_chose_ever():
    dossier_actuel = os.path.dirname(os.path.realpath(__file__))
    chemin_Rese = os.path.join(dossier_actuel, "Of(Reze).py")
    processus = subprocess.Popen(["python", chemin_Rese])