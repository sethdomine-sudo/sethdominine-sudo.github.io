import os
import sys
import pygame
import subprocess
import time
import random

if getattr(sys, 'frozen', False):
    # Si c'est le fichier .exe, on cherche dans le dossier du .exe
    dossier_du_jeu = os.path.dirname(sys.executable)
else:
    # Si c'est le script .py classique, on cherche le dossier du script
    dossier_du_jeu = os.path.dirname(os.path.abspath(__file__))
a =0
# On force Python à se positionner dans le bon dossier de travail
os.chdir(dossier_du_jeu)

pygame.init()

# Dimensions de l'écran
LARGEUR, HAUTEUR = 500, 720
screen = pygame.display.set_mode((LARGEUR, HAUTEUR))
pygame.display.set_caption("APOGIP")

Chifoumi = pygame.transform.scale2x(pygame.image.load("Chifoumi.png").convert_alpha())
Juste_Prix = pygame.transform.scale2x(pygame.image.load("Juste Prix.png").convert_alpha())
Pendu = pygame.transform.scale2x(pygame.image.load("Pendu.png").convert_alpha())
Morpion = pygame.transform.scale2x(pygame.image.load("Morpion.png").convert_alpha())
LsV= pygame.transform.scale2x(pygame.image.load("lSV.png").convert_alpha())

# On crée des Rectangles pour stocker la position de chaque icône
rect_chifoumi = Chifoumi.get_rect(topleft=(100, 100))
rect_juste_prix = Juste_Prix.get_rect(topleft=(300, 100))
rect_pendu = Pendu.get_rect(topleft=(100, 300))
rect_morpion = Morpion.get_rect(topleft=(300, 300))
rect_LsV = LsV.get_rect(topleft=(300, 600))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            with open("TAGRANDMERE.txt", "a") as f:
                f.write("F")
                time.sleep(0.0001)
            with open("Apogip.txt", "a") as f:
                f.write("B")
                time.sleep(0.0001)
                running = False
                pygame.quit()
        elif event.type == pygame.MOUSEBUTTONUP:
            if rect_chifoumi.collidepoint(event.pos):
                subprocess.Popen([sys.executable, "Game.py", "1"])
            if rect_juste_prix.collidepoint(event.pos):
                subprocess.Popen([sys.executable, "Game.py", "2"])
            if rect_pendu.collidepoint(event.pos):
                subprocess.Popen([sys.executable, "Game.py", "3"])
            if rect_morpion.collidepoint(event.pos):
                subprocess.Popen([sys.executable, "Game.py", "4"])
            if rect_LsV.collidepoint(event.pos):
                Nombre=random.randint(1,6)
                with open("Apogip.txt", "a") as f:
                    f.write(str(Nombre))
    screen.fill((50, 50, 65))
    screen.blit(Chifoumi, (100, 100))
    screen.blit(Juste_Prix, (300, 100))
    screen.blit(Pendu, (100, 300))
    screen.blit(Morpion, (300, 300))
    screen.blit(LsV, (300, 600))
    pygame.display.flip()

pygame.quit()
sys.exit()