import time
import random
import threading 
import pygame
import sys 
import os
import Pythoon

if getattr(sys, 'frozen', False):
    # Si c'est le fichier .exe, on cherche dans le dossier du .exe
    dossier_du_jeu = os.path.dirname(sys.executable)
else:
    # Si c'est le script .py classique, on cherche le dossier du script
    dossier_du_jeu = os.path.dirname(os.path.abspath(__file__))
a =0
# On force Python à se positionner dans le bon dossier de travail
os.chdir(dossier_du_jeu)

pygame.init()

# Dimensions de l'écran
LARGEUR, HAUTEUR = 400, 400
screen = pygame.display.set_mode((LARGEUR, HAUTEUR))
#  Variable globale pour savoir si le jeu est fini (gagné ou temps écoulé)
jeu_en_cours = True

pygame.mixer.init()
Jeopardy =pygame.mixer.Sound("Jeopardy.mp3")
son_pile = pygame.mixer.Sound("choix_pile_ou_face.mp3")
son_face = pygame.mixer.Sound("choix_pile_ou_face1.mp3")
pile_face = pygame.mixer.Sound("pile_ou_face.mp3")
son_chifoumi=pygame.mixer.Sound("P-F-C.mp3")
chifoumi_egalité =pygame.mixer.Sound("ega.mp3")
gagnée=pygame.mixer.Sound("gagne.mp3")
perdue=pygame.mixer.Sound("perdu.mp3")
POM_son=pygame.mixer.Sound("POM.mp3")
debut_Pendu=pygame.mixer.Sound("pendu_debut.mp3")
pygame.mixer.music.set_volume(0.5)
def gagner():
    with open("Apogip.txt", "a") as f:
        f.write("G")
def perdu():
    with open("Apogip.txt", "a") as f:
        f.write("P")
def selection(selec):

    if selec == 1:
        chifoumi()
    elif selec==2:
        POM()
    elif selec==3:
        pendu()
    elif selec==4:
        P_O_F()

def chifoumi():
    pygame.display.set_caption("chifoumi")
    police = pygame.font.Font(None, 36)

    pierre =pygame.transform.scale2x(pygame.image.load("Pierre.png").convert_alpha())
    feuille = pygame.transform.scale2x(pygame.image.load("Feuille.png").convert_alpha())
    ciseau=pygame.transform.scale2x(pygame.image.load("Ciseau.png").convert_alpha())

    rect_pierre=pierre.get_rect(topleft=(100, 300))
    rect_feuille=feuille.get_rect(topleft=(200, 300))
    rect_ciseau=ciseau.get_rect(topleft=(300, 300))

    choix=["pierre","feuille","ciseau"]
    robot = 0
    running = True
    score_j=0
    score_I=0

    indice=0
    images = {
        "pierre": pierre,
        "feuille": feuille,
        "ciseau": ciseau
    }
    son_chifoumi.play()
         
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
            elif event.type == pygame.MOUSEBUTTONUP:
                if rect_pierre.collidepoint(event.pos):
                    indice="pierre"
                              
                elif rect_ciseau.collidepoint(event.pos):
                    indice ="ciseau"
                elif rect_feuille.collidepoint(event.pos):
                    indice ="feuille"
                else:
                    indice="nothing"
                robot=random.choice(choix)

        screen.fill((50, 50, 65))
        screen.blit(feuille, (200, 300))
        screen.blit(pierre, (100, 300))
        screen.blit(ciseau, (300, 300))

        txt_consigne = police.render("Pierre,feuille ou ciseau", True, (255, 255, 255))
        screen.blit(txt_consigne, (0, 25))

        score = police.render(f"toi : {score_j},moi(the best Programme) : {score_I}", True, (255, 255, 255))
        screen.blit(score, (0,50))
        
        if robot=="pierre":
            if indice == robot:
                print("egalité")
                chifoumi_egalité.play()
            elif(indice == "pierre" and robot == "ciseau") or \
                (indice == "feuille" and robot == "pierre") or \
                (indice == "ciseau" and robot == "feuille"):
                print("tu as gagné 1 point")
                score_j += 1
                gagnée.play()
            elif(indice == "pierre" and robot == "feuille") or \
                (indice == "feuille" and robot == "ciseau") or \
                (indice == "ciseau" and robot == "pierre"):
                print("j'ai gagné 1 point")
                score_I += 1
                perdue.play()
            else:
                print("nothing")
        if robot=="feuille":
            if indice == robot:
                print("egalité")
                chifoumi_egalité.play()
            elif(indice == "pierre" and robot == "ciseau") or \
                (indice == "feuille" and robot == "pierre") or \
                (indice == "ciseau" and robot == "feuille"):
                print("tu as gagné 1 point")
                score_j += 1
                gagnée.play()
            elif(indice == "pierre" and robot == "feuille") or \
                (indice == "feuille" and robot == "ciseau") or \
                (indice == "ciseau" and robot == "pierre"):
                print("j'ai gagné 1 point")
                score_I += 1
                perdue.play()
            else:
                print("nothing")
        if robot=="ciseau":
            if indice == robot:
                print("egalité")
                chifoumi_egalité.play()
            elif(indice == "pierre" and robot == "ciseau") or \
                (indice == "feuille" and robot == "pierre") or \
                (indice == "ciseau" and robot == "feuille"):
                print("tu as gagné 1 point")
                score_j += 1
                gagnée.play()
            elif(indice == "pierre" and robot == "feuille") or \
                (indice == "feuille" and robot == "ciseau") or \
                (indice == "ciseau" and robot == "pierre"):
                print("j'ai gagné 1 point")
                score_I += 1
                perdue.play()
            else:
                print("nothing")
        
        if robot in images:
            # On affiche l'image choisie par le robot au centre
            screen.blit(images[robot], (200, 200))
            pygame.display.flip()
            time.sleep(1)
        robot=""
        if score_j>2.1:
            
            screen.fill((50, 50, 65))
            screen.blit(feuille, (200, 300))
            screen.blit(pierre, (100, 300))
            screen.blit(ciseau, (300, 300))

            txt_consigne = police.render("Pierre,feuille ou ciseau", True, (255, 255, 255))
            screen.blit(txt_consigne, (0, 25))

            score = police.render(f"toi : {score_j},moi(the best Programme) : {score_I}", True, (255, 255, 255))
            screen.blit(score, (0,50))
            ptn = police.render("T'as gagné ptn", True, (255, 255, 255))
            screen.blit(ptn, (0,0 ))
            gagner()
            pygame.display.flip()
            time.sleep(2)
            pygame.quit()
            sys.exit()
        elif score_I>2.1:
            
            screen.fill((50, 50, 65))
            screen.blit(feuille, (200, 300))
            screen.blit(pierre, (100, 300))
            screen.blit(ciseau, (300, 300))

            txt_consigne = police.render("Pierre,feuille ou ciseau", True, (255, 255, 255))
            screen.blit(txt_consigne, (0, 25))

            score = police.render(f"toi : {score_j},moi(the best Programme) : {score_I}", True, (255, 255, 255))
            screen.blit(score, (0,50))
            yes = police.render("j'ai Gagné", True, (255, 255, 255))
            perdu()
            screen.blit(yes,(0,0))
            pygame.display.flip()
            time.sleep(2)
            pygame.quit()
            sys.exit()        
        pygame.display.flip()

    pygame.quit()
    sys.exit()

def timer():
    global jeu_en_cours
    durée = 60
    while durée >= 0 and jeu_en_cours:
        time.sleep(1)
        durée -= 1
        if durée == 30:
            Jeopardy.play()
            time.sleep(1)
            durée -= 1
    if durée < 0 and jeu_en_cours:
        print("\n\nTrop tard ! Le temps est écoulé !")
        jeu_en_cours=b= False

def POM():
    pygame.display.set_caption("Juste Prix")

    plus =pygame.transform.scale2x(pygame.image.load("+.png").convert_alpha())
    moins=pygame.transform.scale2x(pygame.image.load("-.png").convert_alpha())
    police = pygame.font.Font(None, 36)
    indice =""

    global jeu_en_cours
    jeu_en_cours = True 
    indice = ""
    texte_utilisateur = ""
    a = random.randint(1, 10000) # Pour tester plus vite, j'ai mis entre 1 et 20
    
    # Lancement du timer
    thread_timer = threading.Thread(target=timer)
    thread_timer.daemon = True
    thread_timer.start()

    partie_terminee = False
    temps_fin = 0
    running = True
    POM_son.play()
    while running:

        # 1. GESTION DES ÉVÉNEMENTS (Clavier / Souris)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                jeu_en_cours = False
                running = False

            # On n'écoute le clavier QUE si le jeu est en cours
            elif event.type == pygame.KEYDOWN and jeu_en_cours:
                
                # Effacer un caractère
                if event.key == pygame.K_BACKSPACE:
                    texte_utilisateur = texte_utilisateur[:-1]
                
                # Valider la proposition
                elif event.key == pygame.K_RETURN:
                    if texte_utilisateur.isdigit():  # Vérifie si l'utilisateur a tapé un nombre
                        valeur = int(texte_utilisateur)
                        if valeur > a:
                            indice = "moins"

                        elif valeur < a:
                            indice = "plus"
                        elif valeur==a:
                            indice = "gagne"
                            partie_terminee = True
                            jeu_en_cours = False
                            temps_fin = pygame.time.get_ticks()
                    texte_utilisateur = ""  # Réinitialise la saisie

                # Ajouter un chiffre tapé (seule la saisie numérique est acceptée)
                elif event.unicode.isdigit() and len(texte_utilisateur) < 5:
                    texte_utilisateur += event.unicode
        screen.fill((50, 50, 65))
        if not jeu_en_cours and not partie_terminee:
            indice = "perde"
            partie_terminee = True
            temps_fin = pygame.time.get_ticks()

        if not partie_terminee:
            # Affichage des consignes
            txt_consigne = police.render("Devine entre 1 et 10000", True, (255, 255, 255))
            screen.blit(txt_consigne, (110, 30))

            # Dessin du champ de saisie
            rect_saisie = pygame.Rect(150, 100, 200, 45)
            pygame.draw.rect(screen, (100, 100, 130), rect_saisie, border_radius=8)

            txt_saisie = police.render(texte_utilisateur, True, (255, 255, 255))
            screen.blit(txt_saisie, (rect_saisie.x + 15, rect_saisie.y + 10))
        
            if indice == "moins":
                screen.blit(moins, (100, 180))
            elif indice == "plus":
                screen.blit(plus, (100, 180))
        else:
            if indice =="gagne":
                screen.fill((50, 50, 65))
                Mot = police.render("Malhereusement t'as gagné", True, (255, 255, 255))
                gagner()
                screen.blit(Mot, (50,200))
                pygame.display.flip()
            elif indice =="perde":
                screen.fill((50, 50, 65))
                Mot_p = police.render("perdu!!!", True, (255, 255, 255))
                perdu()
                screen.blit(Mot_p, (200,200))   
                pygame.display.flip() 

            if pygame.time.get_ticks() - temps_fin > 2000:
                running = False
        pygame.display.flip()
    pygame.quit()
    sys.exit()
    
def pendu():
    pygame.display.set_caption("Pendu")
    a=Pythoon.liste
    mot_selectionner = random.choice(a).lower()
    reponce =["_"] * len(mot_selectionner)
    mot_perdu=0
    texte_utilisateur=""
    i=0
    T=random.randint(1,15)
    police = pygame.font.Font(None, 36)
    running = True
    debut_Pendu.play()
    while running:
        # 1. GESTION DES ÉVÉNEMENTS
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:

                if event.key == pygame.K_BACKSPACE:
                    texte_utilisateur = texte_utilisateur[:-1]

                elif event.key == pygame.K_RETURN:  # Valider avec la touche ENTRÉE
                    saisie = texte_utilisateur.lower().strip()
                    texte_utilisateur = ""  # Réinitialiser le champ de saisie

                    # Traitement de la proposition
                    if saisie == mot_selectionner:
                        reponce = list(mot_selectionner)
                        print("Bravo ! Tu as trouvé le mot entier !")
                        gagner()
                        running = False
                    elif len(saisie) == 1 and saisie in mot_selectionner:
                        for index in range(len(mot_selectionner)):
                            if mot_selectionner[index] == saisie:
                                reponce[index] = saisie
                        gagnée.play()
                        
                        if "_" not in reponce:
                            print(f"Gagné ! Le mot était : {mot_selectionner}")
                            gagner()
                            running = False

                    else:
                        mot_perdu += 1
                        print(f"Raté ! Essais restants : {10 - mot_perdu}")
                        perdue.play()
                        if mot_perdu >= 10:
                            print(f"Perdu... Le mot était : {mot_selectionner}")
                            perdu()
                            running = False
                            
                elif event.unicode.isalpha():  # FIX: .isalpha() pour accepter les lettres
                    if len(texte_utilisateur) < 15:
                        texte_utilisateur += event.unicode

        screen.fill((50, 50, 65))

        txt_consigne = police.render("Mon mot est : " + " ".join(reponce), True, (255, 255, 255))
        screen.blit(txt_consigne, (0, 40))

        rect_saisie = pygame.Rect(150, 100, 200, 45)
        pygame.draw.rect(screen, (100, 100, 130), rect_saisie, border_radius=8)

        txt_saisie = police.render(texte_utilisateur, True, (255, 255, 255))
        screen.blit(txt_saisie, (rect_saisie.x + 15, rect_saisie.y + 10))

        txt_demande =police.render("propose moi une lettre ou un mot", True, (255, 255, 255))
        screen.blit(txt_demande, (0, 0))
        txt_saisie = police.render(texte_utilisateur, True, (255, 255, 255))
        screen.blit(txt_saisie, (rect_saisie.x + 15, rect_saisie.y + 10))

        # Affichage du nombre d'essais restants
        txt_essais = police.render(f"Essais restants : {10 - mot_perdu}", True, (200, 200, 200))
        screen.blit(txt_essais, (20, 180))

        # FIX: Incontournable dans Pygame pour rafraîchir l'écran
        pygame.display.flip()
    pygame.quit()

def P_O_F():
    pygame.display.set_caption("pile ou face")
    police = pygame.font.Font(None, 36) 

    choix=0
    choix_ia=0
    score_j=0
    score_I=0
    pile_face.play() 
    message = "Cliquez sur PILE ou FACE !"
    running = True
    pile =pygame.transform.scale2x(pygame.image.load("Pile.png").convert_alpha())
    face = pygame.transform.scale2x(pygame.image.load("Face.png").convert_alpha())

    rect_Pile=pile.get_rect(topleft=(0, 300))
    rect_Face=face.get_rect(topleft=(300, 300))
    clock = pygame.time.Clock()

# 1. CHARGEMENT DE LA SÉQUENCE DE PNG (ex: coin_0.png à coin_11.png)
    NUM_FRAMES = 8
    coin_frames = []
    for i in range(NUM_FRAMES):
        img = pygame.image.load(f"pileouface_{i}.png").convert_alpha()
        img = pygame.transform.scale(img, (100, 100))
        coin_frames.append(img)
    police_piece = pygame.font.Font(None, 50)
    INDEX_PILE = 0
    INDEX_FACE = 8

    # Variables de contrôle de l'animation
    frame_index = 0.0
    anim_speed = 0.0
    flipping = False
    target_frame = INDEX_PILE
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN and not flipping:
                lancer = False
                if rect_Pile.collidepoint(event.pos):
                    choix = 1  # Le joueur parie sur PILE
                    lancer = True
                    son_pile.play()
                elif rect_Face.collidepoint(event.pos):
                    choix = 2  # Le joueur parie sur FACE
                    lancer = True
                    son_face.play()
                if lancer:
                    flipping = True
                    anim_speed = 0.5  # Vitesse du lancer
                    target_frame = random.choice([INDEX_PILE, INDEX_FACE])
                    message = "La pièce tourne..."
        # LOGIQUE DE L'ANIMATION ET VICTOIRE
        if flipping:
            frame_index += anim_speed
            anim_speed *= 0.97  # Ralentissement progressif

            # QUAND LA VITESSE DEVIENT TROP FAIBLE, ON ARRÊTE DIRECTEMENT
            if anim_speed < 0.05:
                flipping = False
                frame_index = target_frame  # On force l'affichage sur la face gagnante
                
                # VERIFICATION DU GAGNANT
                resultat = 1 if target_frame == INDEX_PILE else 2
                
                if choix == resultat:
                    score_j += 1
                    message = "GAGNÉ !"
                    gagnée.play()                    
                else:
                    score_I += 1
                    message = "PERDU !"
                    perdue.play()
                
        current_image = coin_frames[int(frame_index) % NUM_FRAMES]
        current_frame = int(frame_index) % NUM_FRAMES
        est_cote_pile = (current_frame <= 2 or current_frame >= 6)

        if est_cote_pile:
            lettre = "P"
        else:
            lettre = "F"

        hauteur_image = current_image.get_height()
        if hauteur_image > 30:  # Seulement si la pièce n'est pas vue de tranche
            txt_lettre = police_piece.render(lettre, True, (40, 40, 40))
            # Ajustement de la taille du texte pour qu'il s'écrase en même temps que la pièce
            echelle_y = max(1, int(txt_lettre.get_height() * (hauteur_image / 110)))
            txt_redim = pygame.transform.scale(txt_lettre, (txt_lettre.get_width(), echelle_y))
            
            rect_txt = txt_redim.get_rect(center=(current_image.get_width() // 2, current_image.get_height() // 2))
            current_image.blit(txt_redim, rect_txt)

        # AFFICHAGE
        screen.fill((30, 30, 30))

        # 1. Scores et Message
        txt_score = police.render(f"Joueur: {score_j}   |   APOGIP(the best): {score_I}", True, (255, 255, 255))
        screen.blit(txt_score, txt_score.get_rect(center=(LARGEUR // 2, 30)))

        txt_msg = police.render(message, True, (240, 200, 50))
        screen.blit(txt_msg, txt_msg.get_rect(center=(LARGEUR // 2, 75)))

        # 2. Pièce animée au centre
        rect_coin = current_image.get_rect(center=(LARGEUR // 2, 220))
        screen.blit(current_image, rect_coin)

        # 3. Boutons de choix cliquables
        screen.blit(pile, rect_Pile)
        screen.blit(face, rect_Face)
        pygame.display.flip()
        clock.tick(60)
        if score_I ==10 :
            running=False
            perdu()
        if score_j ==10 :
            running=False
            gagner()
    pygame.quit()
    sys.exit()
        
if __name__ == "__main__":
    # sys.argv contient les arguments donnés au lancement.
    # sys.argv[0] est le nom du fichier (Game.py)
    # sys.argv[1] sera le "1" ou le "2" envoyé par la plateforme
    
    if len(sys.argv) > 1: 
        choix_jeu = int(sys.argv[1]) # On convertit le texte "1" en nombre 1
        selection(choix_jeu)
    if len(sys.argv) > 2: 
        choix_jeu = int(sys.argv[1])
        selection(choix_jeu)
    if len(sys.argv) > 3: 
        choix_jeu = int(sys.argv[1])
        selection(choix_jeu)
    if len(sys.argv) > 4: 
        choix_jeu = int(sys.argv[1])
        selection(choix_jeu)
