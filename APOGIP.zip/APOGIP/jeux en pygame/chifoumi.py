import time
import random
import pygame
import os
import sys

if getattr(sys, 'frozen', False):
    # Si c'est le fichier .exe, on cherche dans le dossier du .exe
    dossier_du_jeu = os.path.dirname(sys.executable)
else:
    # Si c'est le script .py classique, on cherche le dossier du script
    dossier_du_jeu = os.path.dirname(os.path.abspath(__file__))
a =0
# On force Python à se positionner dans le bon dossier de travail
os.chdir(dossier_du_jeu)

pygame.init()

# Dimensions de l'écran
LARGEUR, HAUTEUR = 400, 400
screen = pygame.display.set_mode((LARGEUR, HAUTEUR))
pygame.display.set_caption("chifoumi")
police = pygame.font.Font(None, 36)

pierre =pygame.transform.scale2x(pygame.image.load("Pierre.png").convert_alpha())
feuille = pygame.transform.scale2x(pygame.image.load("Feuille.png").convert_alpha())
ciseau=pygame.transform.scale2x(pygame.image.load("Ciseau.png").convert_alpha())

rect_pierre=pierre.get_rect(topleft=(100, 300))
rect_feuille=feuille.get_rect(topleft=(200, 300))
rect_ciseau=ciseau.get_rect(topleft=(300, 300))

choix=["pierre","feuille","ciseau"]
robot = 0
running = True
score_j=0
score_I=0

indice=0
images = {
    "pierre": pierre,
    "feuille": feuille,
    "ciseau": ciseau
}
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
        elif event.type == pygame.MOUSEBUTTONUP:
            if rect_pierre.collidepoint(event.pos):
                indice="pierre"
            elif rect_ciseau.collidepoint(event.pos):
                indice ="ciseau"
            elif rect_feuille.collidepoint(event.pos):
                indice ="feuille"
            else:
                indice="nothing"
            robot=random.choice(choix)
            if indice == robot:
                print("egalité")
            elif(indice == "pierre" and robot == "ciseau") or \
                (indice == "feuille" and robot == "pierre") or \
                (indice == "ciseau" and robot == "feuille"):
                    print("tu as gagné 1 point")
                    score_j += 1
            elif(indice == "pierre" and robot == "feuille") or \
                (indice == "feuille" and robot == "ciseau") or \
                (indice == "ciseau" and robot == "pierre"):
                print("j'ai gagné 1 point")
                score_I += 1
            else:
                print("nothing")
            
    screen.fill((50, 50, 65))
    screen.blit(feuille, (200, 300))
    screen.blit(pierre, (100, 300))
    screen.blit(ciseau, (300, 300))

    txt_consigne = police.render("Pierre,feuille ou ciseau", True, (255, 255, 255))
    screen.blit(txt_consigne, (0, 25))

    score = police.render(f"toi : {score_j},moi(the best Programme) : {score_I}", True, (255, 255, 255))
    screen.blit(score, (0,50))

    
    if robot in images:
        # On affiche l'image choisie par le robot au centre
        screen.blit(images[robot], (200, 200))
    robot=""
    if score_j>2.1:
        
        screen.fill((50, 50, 65))
        screen.blit(feuille, (200, 300))
        screen.blit(pierre, (100, 300))
        screen.blit(ciseau, (300, 300))

        txt_consigne = police.render("Pierre,feuille ou ciseau", True, (255, 255, 255))
        screen.blit(txt_consigne, (0, 25))

        score = police.render(f"toi : {score_j},moi(the best Programme) : {score_I}", True, (255, 255, 255))
        screen.blit(score, (0,50))
        ptn = police.render("T'as gagné ptn", True, (255, 255, 255))
        screen.blit(ptn, (0,0 ))
        pygame.display.flip()
        time.sleep(2)
        pygame.quit()
        sys.exit()
    elif score_I>2.1:
        
        screen.fill((50, 50, 65))
        screen.blit(feuille, (200, 300))
        screen.blit(pierre, (100, 300))
        screen.blit(ciseau, (300, 300))

        txt_consigne = police.render("Pierre,feuille ou ciseau", True, (255, 255, 255))
        screen.blit(txt_consigne, (0, 25))

        score = police.render(f"toi : {score_j},moi(the best Programme) : {score_I}", True, (255, 255, 255))
        screen.blit(score, (0,50))
        yes = police.render("j'ai Gagné", True, (255, 255, 255))
        screen.blit(yes,(0,0))
        pygame.display.flip()
        time.sleep(2)
        pygame.quit()
        sys.exit()        
    pygame.display.flip()

pygame.quit()
sys.exit()