import time
import random
import pygame
import os
import sys

if getattr(sys, 'frozen', False):
    # Si c'est le fichier .exe, on cherche dans le dossier du .exe
    dossier_du_jeu = os.path.dirname(sys.executable)
else:
    # Si c'est le script .py classique, on cherche le dossier du script
    dossier_du_jeu = os.path.dirname(os.path.abspath(__file__))
a =0
# On force Python à se positionner dans le bon dossier de travail
os.chdir(dossier_du_jeu)
pygame.init()
LARGEUR, HAUTEUR = 400, 400
screen = pygame.display.set_mode((LARGEUR, HAUTEUR))

def P_O_F():
    pygame.display.set_caption("pile ou face")
    police = pygame.font.Font(None, 36) 

    choix=0
    choix_ia=0
    score_j=0
    score_I=0
    pygame.mixer.music.load("pile_ou_face.mp3")
    pygame.mixer.music.play(0)   
    son_pile = pygame.mixer.Sound("choix_pile_ou_face.mp3")
    son_face = pygame.mixer.Sound("choix_pile_ou_face1.mp3")
    message = "Cliquez sur PILE ou FACE !"
    running = True
    pile =pygame.transform.scale2x(pygame.image.load("Pile.png").convert_alpha())
    face = pygame.transform.scale2x(pygame.image.load("Face.png").convert_alpha())

    rect_Pile=pile.get_rect(topleft=(0, 300))
    rect_Face=face.get_rect(topleft=(300, 300))
    clock = pygame.time.Clock()

# 1. CHARGEMENT DE LA SÉQUENCE DE PNG (ex: coin_0.png à coin_11.png)
    NUM_FRAMES = 8
    coin_frames = []
    for i in range(NUM_FRAMES):
        img = pygame.image.load(f"pileouface_{i}.png").convert_alpha()
        img = pygame.transform.scale(img, (100, 100))
        coin_frames.append(img)

    INDEX_PILE = 0
    INDEX_FACE = 8

    # Variables de contrôle de l'animation
    frame_index = 0.0
    anim_speed = 0.0
    flipping = False
    target_frame = INDEX_PILE

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN and not flipping:
                lancer = False
                if rect_Pile.collidepoint(event.pos):
                    choix = 1  # Le joueur parie sur PILE
                    lancer = True
                    son_pile.play()
                elif rect_Face.collidepoint(event.pos):
                    choix = 2  # Le joueur parie sur FACE
                    lancer = True
                    son_face.play()
                if lancer:
                    flipping = True
                    anim_speed = 0.5  # Vitesse du lancer
                    target_frame = random.choice([INDEX_PILE, INDEX_FACE])
                    message = "La pièce tourne..."
        # LOGIQUE DE L'ANIMATION ET VICTOIRE
        if flipping:
            frame_index += anim_speed
            anim_speed *= 0.97  # Ralentissement progressif

            # QUAND LA VITESSE DEVIENT TROP FAIBLE, ON ARRÊTE DIRECTEMENT
            if anim_speed < 0.05:
                flipping = False
                frame_index = target_frame  # On force l'affichage sur la face gagnante
                
                # VERIFICATION DU GAGNANT
                resultat = 1 if target_frame == INDEX_PILE else 2
                
                
                if choix == resultat:
                    score_j += 1
                    message = "GAGNÉ !"
                else:
                    score_I += 1
                    message = "PERDU !"
                if score_I ==10 :
                    running=False
                if score_j ==10 :
                    running=False
        current_image = coin_frames[int(frame_index) % NUM_FRAMES]

        # AFFICHAGE
        screen.fill((30, 30, 30))

        # 1. Scores et Message
        txt_score = police.render(f"Joueur: {score_j}   |   APOGIP(the best): {score_I}", True, (255, 255, 255))
        screen.blit(txt_score, txt_score.get_rect(center=(LARGEUR // 2, 30)))

        txt_msg = police.render(message, True, (240, 200, 50))
        screen.blit(txt_msg, txt_msg.get_rect(center=(LARGEUR // 2, 75)))

        # 2. Pièce animée au centre
        rect_coin = current_image.get_rect(center=(LARGEUR // 2, 220))
        screen.blit(current_image, rect_coin)

        # 3. Boutons de choix cliquables
        screen.blit(pile, rect_Pile)
        screen.blit(face, rect_Face)
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()
P_O_F()