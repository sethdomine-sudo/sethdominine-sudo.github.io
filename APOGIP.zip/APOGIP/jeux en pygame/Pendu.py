import time
import random
import pygame
import Pythoon

pygame.init()

def pendu():
    LARGEUR, HAUTEUR = 400,400
    screen = pygame.display.set_mode((LARGEUR, HAUTEUR))
    pygame.display.set_caption("Pendu")
    a=Pythoon.liste
    mot_selectionner = random.choice(a).lower()
    reponce =["_"] * len(mot_selectionner)
    mot_perdu=0
    texte_utilisateur=""
    i=0
    T=random.randint(1,15)
    police = pygame.font.Font(None, 36)
    running = True
    while running:
        # 1. GESTION DES ÉVÉNEMENTS
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:

                if event.key == pygame.K_BACKSPACE:
                    texte_utilisateur = texte_utilisateur[:-1]

                elif event.key == pygame.K_RETURN:  # Valider avec la touche ENTRÉE
                    saisie = texte_utilisateur.lower().strip()
                    texte_utilisateur = ""  # Réinitialiser le champ de saisie

                    # Traitement de la proposition
                    if saisie == mot_selectionner:
                        reponce = list(mot_selectionner)
                        print("Bravo ! Tu as trouvé le mot entier !")
                        jeu_en_cours = False

                    elif len(saisie) == 1 and saisie in mot_selectionner:
                        for index in range(len(mot_selectionner)):
                            if mot_selectionner[index] == saisie:
                                reponce[index] = saisie
                        
                        if "_" not in reponce:
                            print(f"Gagné ! Le mot était : {mot_selectionner}")
                            jeu_en_cours = False

                    else:
                        mot_perdu += 1
                        print(f"Raté ! Essais restants : {10 - mot_perdu}")
                        if mot_perdu >= 10:
                            print(f"Perdu... Le mot était : {mot_selectionner}")
                            jeu_en_cours = False

                elif event.unicode.isalpha():  # FIX: .isalpha() pour accepter les lettres
                    if len(texte_utilisateur) < 15:
                        texte_utilisateur += event.unicode

        screen.fill((50, 50, 65))

        txt_consigne = police.render("Mon mot est : " + " ".join(reponce), True, (255, 255, 255))
        screen.blit(txt_consigne, (0, 40))

        rect_saisie = pygame.Rect(150, 100, 200, 45)
        pygame.draw.rect(screen, (100, 100, 130), rect_saisie, border_radius=8)

        txt_saisie = police.render(texte_utilisateur, True, (255, 255, 255))
        screen.blit(txt_saisie, (rect_saisie.x + 15, rect_saisie.y + 10))

        txt_demande =police.render("propose moi une lettre ou un mot", True, (255, 255, 255))
        screen.blit(txt_demande, (0, 0))
        txt_saisie = police.render(texte_utilisateur, True, (255, 255, 255))
        screen.blit(txt_saisie, (rect_saisie.x + 15, rect_saisie.y + 10))

        # Affichage du nombre d'essais restants
        txt_essais = police.render(f"Essais restants : {10 - mot_perdu}", True, (200, 200, 200))
        screen.blit(txt_essais, (20, 180))

        # FIX: Incontournable dans Pygame pour rafraîchir l'écran
        pygame.display.flip()

    pygame.quit()
        
                    
    while mot_perdu < 10:
        print("Mon mot est : " + " ".join(reponce))
        b = input("propose moi une lettre ou un mot : ").lower().strip()
        
        # 1. On vérifie d'abord le mot ENTIER
        if b == mot_selectionner:
            print("malhereusement t'as gagné")
            reponce = list(mot_selectionner) # On affiche le mot complet
            break # On arrête le jeu proprement
            
        # 2. Si ce n'est pas le mot entier, on regarde si c'est UNE seule bonne lettre
        elif len(b) == 1 and b in mot_selectionner:
            for index in range(len(mot_selectionner)):
                if mot_selectionner[index] == b:
                    reponce[index] = b
            
            # On vérifie si toutes les lettres ont été trouvées une par une
            if "_" not in reponce:
                print(f"Bravo ! Tu as trouvé toutes les lettres. Le mot était : {mot_selectionner}")
                break
                
        # 3. Si c'est une mauvaise lettre ou un mauvais mot
        else:
            print("Eh benn nonn")
            mot_perdu += 1
            print(f"Essais restants : {10 - mot_perdu}")
            if mot_perdu==10:
                print(f"c'etait{mot_selectionner}")
                print("tu as perdu")
                print("préparation de ta defaite")
        pygame.display.flip()
pendu()