import time
import threading
import random
import pygame
import os
import sys

if getattr(sys, 'frozen', False):
    # Si c'est le fichier .exe, on cherche dans le dossier du .exe
    dossier_du_jeu = os.path.dirname(sys.executable)
else:
    # Si c'est le script .py classique, on cherche le dossier du script
    dossier_du_jeu = os.path.dirname(os.path.abspath(__file__))
a =0
# On force Python à se positionner dans le bon dossier de travail
os.chdir(dossier_du_jeu)
pygame.init()
police = pygame.font.Font(None, 36)
pygame.mixer.init()
pygame.mixer.music.load("Jeopardy.mp3")
pygame.mixer.music.set_volume(0.5)
def timer():
    global jeu_en_cours
    durée = 31
    while durée >= 0 and jeu_en_cours:
        time.sleep(1)
        durée -= 1
        if durée == 30:
            pygame.mixer.music.play(0)
            time.sleep(1)
            durée -= 1
    if durée < 0 and jeu_en_cours:
        print("\n\nTrop tard ! Le temps est écoulé !")
        jeu_en_cours=b= False

def POM():
    LARGEUR, HAUTEUR = 400,400
    screen = pygame.display.set_mode((LARGEUR, HAUTEUR))
    pygame.display.set_caption("Juste Prix")

    plus =pygame.transform.scale2x(pygame.image.load("+.png").convert_alpha())
    moins=pygame.transform.scale2x(pygame.image.load("-.png").convert_alpha())
    police = pygame.font.Font(None, 36)
    indice =""

    global jeu_en_cours
    jeu_en_cours = True 
    indice = ""
    texte_utilisateur = ""
    a = random.randint(1, 20) # Pour tester plus vite, j'ai mis entre 1 et 20
    
    # Lancement du timer
    thread_timer = threading.Thread(target=timer)
    thread_timer.daemon = True
    thread_timer.start()

    clock = pygame.time.Clock()
    running = True

    partie_terminee = False
    temps_fin = 0
    while running:

        # 1. GESTION DES ÉVÉNEMENTS (Clavier / Souris)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                jeu_en_cours = False
                running = False

            # On n'écoute le clavier QUE si le jeu est en cours
            elif event.type == pygame.KEYDOWN and jeu_en_cours:
                
                # Effacer un caractère
                if event.key == pygame.K_BACKSPACE:
                    texte_utilisateur = texte_utilisateur[:-1]
                
                # Valider la proposition
                elif event.key == pygame.K_RETURN:
                    if texte_utilisateur.isdigit():  # Vérifie si l'utilisateur a tapé un nombre
                        valeur = int(texte_utilisateur)
                        if valeur > a:
                            indice = "moins"
                        elif valeur < a:
                            indice = "plus"
                        elif valeur==a:
                            indice = "gagne"
                            partie_terminee = True
                            jeu_en_cours = False
                            temps_fin = pygame.time.get_ticks()
                    texte_utilisateur = ""  # Réinitialise la saisie

                # Ajouter un chiffre tapé (seule la saisie numérique est acceptée)
                elif event.unicode.isdigit() and len(texte_utilisateur) < 5:
                    texte_utilisateur += event.unicode
        screen.fill((50, 50, 65))
        if not jeu_en_cours and not partie_terminee:
            indice = "perde"
            partie_terminee = True
            temps_fin = pygame.time.get_ticks()

        if not partie_terminee:
            # Affichage des consignes
            txt_consigne = police.render("Devine entre 1 et 10000", True, (255, 255, 255))
            screen.blit(txt_consigne, (110, 30))

            # Dessin du champ de saisie
            rect_saisie = pygame.Rect(150, 100, 200, 45)
            pygame.draw.rect(screen, (100, 100, 130), rect_saisie, border_radius=8)

            txt_saisie = police.render(texte_utilisateur, True, (255, 255, 255))
            screen.blit(txt_saisie, (rect_saisie.x + 15, rect_saisie.y + 10))
        
            if indice == "moins":
                screen.blit(moins, (100, 180))
            elif indice == "plus":
                screen.blit(plus, (100, 180))
        else:
            if indice =="gagne":
                screen.fill((50, 50, 65))
                Mot = police.render("Malhereusement t'as gagné", True, (255, 255, 255))
                screen.blit(Mot, (50,200))
                pygame.display.flip()
            elif indice =="perde":
                screen.fill((50, 50, 65))
                Mot_p = police.render("perdu!!!", True, (255, 255, 255))
                screen.blit(Mot_p, (200,200))   
                pygame.display.flip() 

            if pygame.time.get_ticks() - temps_fin > 2000:
                running = False
        pygame.display.flip()
    pygame.quit()
    sys.exit()


POM()

#import pygame
#from pygame.locals import *
# 
#pygame.init()
 
#fenetre = pygame.display.set_mode((1366, 768))
 
#font=pygame.font.Font(None, 24)
##text = font.render("Texte",1,(255,255,255))
###### 
#continuer = 1
# 
#while continuer:
 #
 #   for event in pygame.event.get():
 #       if event.type == QUIT:
 #           continuer = 0
 #
 #   fenetre.blit(text, (300, 300))
 #
 #   pygame.display.flip()
# 
#pygame.quit()#