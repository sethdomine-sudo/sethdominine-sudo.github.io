from gtts import gTTS
import os

# 1. On crée un dictionnaire avec toutes les phrases de ton jeu
# Donne un nom clair à la clé pour savoir quand jouer le son !
catalogue_phrases = {
    "DEBUT_2-1":"Rappelle toi ,tu es dans mon monde",
}

# 2. Créer le dossier "sons" s'il n'existe pas déjà
if not os.path.exists("sons"):
    os.makedirs("sons")

# 3. Boucle pour transformer chaque phrase en fichier audio
print("Génération des fichiers audio en cours...")
for nom_fichier, texte in catalogue_phrases.items():
    # Génère la voix (lang='fr' pour le français)
    tts = gTTS(text=texte, lang='fr', slow=False)
    
    # Sauvegarde directement dans le dossier "sons"
    chemin_final = f"sons/{nom_fichier}.mp3"
    tts.save(chemin_final)
    print(f"-> Fichier créé : {chemin_final}")

print("\nTerminé ! Tous tes fichiers sont prêts pour le jeu.")