import os
import subprocess

def Kaboom():
    Deux=0
    while Deux<1:
        dossier_actuel = os.path.dirname(os.path.realpath(__file__))
        chemin_Rese = os.path.join(dossier_actuel, "Of(Reze).py")
        processus = subprocess.Popen(["python",chemin_Rese])
Kaboom()