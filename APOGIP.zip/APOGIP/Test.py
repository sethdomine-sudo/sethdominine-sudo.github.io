import os

dossier_actuel = os.path.dirname(os.path.realpath(__file__))
Mon = os.path.join(dossier_actuel, "Image_Idée.png")